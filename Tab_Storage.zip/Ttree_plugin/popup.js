function sayHello(){
    document.body.innerText = "test";
}
window.onload = sayHello;
